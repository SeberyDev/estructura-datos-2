//import { Clase1 } from "./clase1.js"; 
import A from "./clase1.js"

//let clase1 = new Clase1();  
let clase1 = new A();

console.log(clase1.propiedad1);