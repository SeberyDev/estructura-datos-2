class Clase1 {
    constructor(){
        this.propiedad1 = 8;
    }
}

//export {Clase1};

export default Clase1;